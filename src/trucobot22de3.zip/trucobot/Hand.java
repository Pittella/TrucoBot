package trucobot;

public class Hand {
    
    public Card[] HandArray = new Card[3];
    
    
    public void SetCards(Card x, Card y, Card z){ 
        this.HandArray[0] = x;
        this.HandArray[1] = y;
        this.HandArray[2] = z;
    }
       
    
}
