package trucobot;   

public class TrucoBot {

    public static void main(String[] args) {
        //MAIN CODE
        PlayingTruco p = new PlayingTruco();
        p.TestarCoisasETC();
        
        //System.out.println("Hello world");     
        
    }
    
}
